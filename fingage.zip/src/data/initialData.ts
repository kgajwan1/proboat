import { 
  InventoryItem, 
  LowStockActionItem, 
  InvoiceItem, 
  BillItem, 
  EmployeePayroll, 
  TaxDeadline, 
  BusinessStats 
} from '../types';

export const INITIAL_STATS: BusinessStats = {
  totalRevenue: 45230,
  revenueGrowthPct: 12.0,
  pendingBillsTotal: 3150,
  pendingBillsCount: 5,
  dueSoonBillsCount: 3,
  expectedIncome: 8500,
  expectedExpenses: 6100,
  projectedProfit: 2400,
  totalInventoryItems: 12450,
  totalSkus: 420,
  lowStockAlertsCount: 12,
  totalMonthlyPayroll: 24500.00,
  totalTaxesWithheld: 6125.50,
  ytdTaxContributions: 42875.00,
  annualTaxEstimate: 65000.00,
};

export const INITIAL_INVOICES: InvoiceItem[] = [
  {
    id: 'inv-1',
    client: 'Acme Corp',
    initial: 'A',
    amount: 1200,
    dueDateText: 'Due 2 days ago',
    dueDate: '2026-08-25',
    isOverdue: true,
    status: 'due',
    avatarColor: 'primary',
    invoiceNumber: 'INV-2026-089',
    items: ['UX Research & Wireframing', 'Sprint 3 Design Deliverables']
  },
  {
    id: 'inv-2',
    client: 'Sarah Jenkins',
    initial: 'S',
    amount: 450,
    dueDateText: 'Due today',
    dueDate: '2026-08-27',
    isOverdue: false,
    status: 'due',
    avatarColor: 'secondary',
    invoiceNumber: 'INV-2026-090',
    items: ['Brand Consulting Session', 'Typography Styleguide']
  },
  {
    id: 'inv-3',
    client: 'Global Tech',
    initial: 'G',
    amount: 3800,
    dueDateText: 'Due in 5 days',
    dueDate: '2026-09-01',
    isOverdue: false,
    status: 'not_due',
    avatarColor: 'neutral',
    invoiceNumber: 'INV-2026-091',
    items: ['Cloud Infrastructure Audit', 'Quarterly Maintenance retainer']
  },
  {
    id: 'inv-4',
    client: 'Apex Logistics',
    initial: 'A',
    amount: 2150,
    dueDateText: 'Due in 10 days',
    dueDate: '2026-09-06',
    isOverdue: false,
    status: 'not_due',
    avatarColor: 'primary',
    invoiceNumber: 'INV-2026-092',
    items: ['Route Optimizer UI integration', 'API Webhooks setup']
  }
];

export const INITIAL_BILLS: BillItem[] = [
  {
    id: 'bill-1',
    vendor: 'AWS Cloud Services',
    category: 'Hosting & Infrastructure',
    amount: 1450,
    dueDate: '2026-08-29',
    isDueSoon: true,
    status: 'pending',
    accountNumber: 'AWS-892144-US'
  },
  {
    id: 'bill-2',
    vendor: 'Workspace Office Leasing',
    category: 'Facilities & Rent',
    amount: 1100,
    dueDate: '2026-08-30',
    isDueSoon: true,
    status: 'pending',
    accountNumber: 'PROP-LEASE-502'
  },
  {
    id: 'bill-3',
    vendor: 'Google Workspace Enterprise',
    category: 'Software & SaaS',
    amount: 600,
    dueDate: '2026-08-31',
    isDueSoon: true,
    status: 'pending',
    accountNumber: 'GSUITE-SUB-991'
  },
  {
    id: 'bill-4',
    vendor: 'Figma Organization Tier',
    category: 'Software & SaaS',
    amount: 360,
    dueDate: '2026-09-12',
    isDueSoon: false,
    status: 'pending',
    accountNumber: 'FIG-ORG-3341'
  },
  {
    id: 'bill-5',
    vendor: 'Courier & Freight Logistics',
    category: 'Shipping',
    amount: 240,
    dueDate: '2026-09-15',
    isDueSoon: false,
    status: 'pending',
    accountNumber: 'LOG-EXP-1102'
  }
];

export const INITIAL_MOST_USED_ITEMS: InventoryItem[] = [
  {
    id: 'inv-item-1',
    name: 'Premium Printer Paper A4',
    sku: 'PPR-A4-001',
    category: 'Office Supplies',
    inStock: 2450,
    threshold: 500,
    unitPrice: 14.50,
    iconType: 'print',
    lastRestocked: 'Aug 14, 2026'
  },
  {
    id: 'inv-item-2',
    name: 'Artisan Coffee Beans',
    sku: 'COF-BNS-092',
    category: 'Pantry',
    inStock: 840,
    threshold: 200,
    unitPrice: 22.00,
    iconType: 'coffee_maker',
    lastRestocked: 'Aug 20, 2026'
  },
  {
    id: 'inv-item-3',
    name: 'Gel Pens (Black)',
    sku: 'PEN-GEL-BLK',
    category: 'Office Supplies',
    inStock: 1200,
    threshold: 300,
    unitPrice: 1.80,
    iconType: 'edit',
    lastRestocked: 'Aug 10, 2026'
  },
  {
    id: 'inv-item-4',
    name: 'Shipping Boxes (Medium)',
    sku: 'PKG-BOX-MED',
    category: 'Packaging',
    inStock: 3100,
    threshold: 750,
    unitPrice: 2.40,
    iconType: 'local_shipping',
    lastRestocked: 'Aug 18, 2026'
  },
  {
    id: 'inv-item-5',
    name: 'Bubble Wrap Roll (50m)',
    sku: 'PKG-BBL-050',
    category: 'Packaging',
    inStock: 450,
    threshold: 100,
    unitPrice: 18.00,
    iconType: 'box',
    lastRestocked: 'Aug 05, 2026'
  },
  {
    id: 'inv-item-6',
    name: 'Wireless Bluetooth Keyboards',
    sku: 'IT-KBD-WRL',
    category: 'IT Equipment',
    inStock: 65,
    threshold: 20,
    unitPrice: 79.99,
    iconType: 'box',
    lastRestocked: 'Jul 28, 2026'
  }
];

export const INITIAL_LOW_STOCK_ALERTS: LowStockActionItem[] = [
  {
    id: 'alert-1',
    name: 'Ergonomic Mouse',
    sku: 'IT-MSE-004',
    inStock: 2,
    threshold: 10,
    severity: 'critical',
    category: 'IT Equipment',
    unitCost: 45.00,
    supplier: 'LogiTech Supply Direct',
    suggestedReorder: 25
  },
  {
    id: 'alert-2',
    name: 'Toner Cartridge (Cyan)',
    sku: 'PRT-TNR-CYN',
    inStock: 5,
    threshold: 15,
    severity: 'low',
    category: 'Office Supplies',
    unitCost: 68.50,
    supplier: 'HP Imaging Commercial',
    suggestedReorder: 20
  },
  {
    id: 'alert-3',
    name: 'Meeting Room Notepads',
    sku: 'OFF-NTP-A5',
    inStock: 12,
    threshold: 50,
    severity: 'low',
    category: 'Office Supplies',
    unitCost: 3.20,
    supplier: 'PaperCraft Wholesale',
    suggestedReorder: 100
  },
  {
    id: 'alert-4',
    name: 'USB-C Multiport Adapters',
    sku: 'IT-ADP-HUB',
    inStock: 3,
    threshold: 12,
    severity: 'critical',
    category: 'IT Equipment',
    unitCost: 28.00,
    supplier: 'Anker B2B Solutions',
    suggestedReorder: 30
  },
  {
    id: 'alert-5',
    name: 'Sanitizing Disinfectant Wipes',
    sku: 'SAN-WIP-001',
    inStock: 8,
    threshold: 30,
    severity: 'low',
    category: 'Pantry',
    unitCost: 6.50,
    supplier: 'CleanCo Commercial',
    suggestedReorder: 50
  }
];

export const INITIAL_EMPLOYEES: EmployeePayroll[] = [
  {
    id: 'emp-1',
    name: 'Sarah Jenkins',
    role: 'Lead Designer',
    initials: 'SJ',
    badgeColor: 'primary',
    grossPay: 5200.00,
    taxDeduction: 1144.00,
    netPay: 4056.00,
    payDate: 'Oct 15, 2026',
    hoursWorked: 80,
    directDepositAccount: '•••• 4920 (Chase Bank)',
    taxBreakdown: {
      federal: 624.00,
      state: 260.00,
      fica: 184.60,
      medicare: 75.40
    }
  },
  {
    id: 'emp-2',
    name: 'Marcus Reed',
    role: 'Senior Developer',
    initials: 'MR',
    badgeColor: 'tertiary',
    grossPay: 6800.00,
    taxDeduction: 1632.00,
    netPay: 5168.00,
    payDate: 'Oct 15, 2026',
    hoursWorked: 80,
    directDepositAccount: '•••• 8812 (Wells Fargo)',
    taxBreakdown: {
      federal: 952.00,
      state: 340.00,
      fica: 241.40,
      medicare: 98.60
    }
  },
  {
    id: 'emp-3',
    name: 'Alicia Lee',
    role: 'Marketing Mgr',
    initials: 'AL',
    badgeColor: 'secondary',
    grossPay: 4500.00,
    taxDeduction: 945.00,
    netPay: 3555.00,
    payDate: 'Oct 15, 2026',
    hoursWorked: 80,
    directDepositAccount: '•••• 1045 (Bank of America)',
    taxBreakdown: {
      federal: 517.50,
      state: 225.00,
      fica: 159.75,
      medicare: 65.25
    }
  },
  {
    id: 'emp-4',
    name: 'David Chen',
    role: 'Product Operations',
    initials: 'DC',
    badgeColor: 'primary',
    grossPay: 4800.00,
    taxDeduction: 1056.00,
    netPay: 3744.00,
    payDate: 'Oct 15, 2026',
    hoursWorked: 80,
    directDepositAccount: '•••• 3371 (Citibank)',
    taxBreakdown: {
      federal: 576.00,
      state: 240.00,
      fica: 170.40,
      medicare: 69.60
    }
  },
  {
    id: 'emp-5',
    name: 'Elena Rostova',
    role: 'Customer Success Specialist',
    initials: 'ER',
    badgeColor: 'tertiary',
    grossPay: 3200.00,
    taxDeduction: 648.50,
    netPay: 2551.50,
    payDate: 'Oct 15, 2026',
    hoursWorked: 80,
    directDepositAccount: '•••• 7729 (US Bank)',
    taxBreakdown: {
      federal: 352.00,
      state: 160.00,
      fica: 113.60,
      medicare: 46.40
    }
  }
];

export const INITIAL_TAX_DEADLINES: TaxDeadline[] = [
  {
    id: 'dl-1',
    title: 'Q3 941 Form Due',
    subtitle: 'Federal Employer Tax',
    month: 'Oct',
    day: '15',
    isUrgent: true,
    status: 'upcoming'
  },
  {
    id: 'dl-2',
    title: 'State Unemployment',
    subtitle: 'Quarterly Filing',
    month: 'Oct',
    day: '31',
    isUrgent: false,
    status: 'upcoming'
  },
  {
    id: 'dl-3',
    title: 'Form 940 Annual FUTA',
    subtitle: 'Federal Unemployment',
    month: 'Nov',
    day: '15',
    isUrgent: false,
    status: 'upcoming'
  }
];

export const PROFILE_AVATARS = {
  default: "https://lh3.googleusercontent.com/aida-public/AB6AXuBeBHNbn6gH5rQYSUQJSW_3kyknjNzVhxqIC4vA9SbxxEL5X6I0jPOVzZQ1RBTJ9pEjx39YK_OvBnUp9WkTT02RjHHkp7Mbji4xwJlbH8VNmJFsNpMW82wV7sSN6FvqkEuV0S59TnrvtcpIYfrXozJ6M4txhQnwI0M1wWMv4T71LbCo0u54y2pp3Djt1W539Y9PiF6dP5g4fNKrlQH79qCl8cJt_HkPy8yE5xn4tsPz0bG3aJp1My0gpg",
  inventory: "https://lh3.googleusercontent.com/aida-public/AB6AXuBPBVwarmzBIRP5WXXCPoOrfto941EIJCENPjyKUTW3Uoz71-qxCQVQtbPXr4SnNAGwUIu8ekuWoDfnf2zADDFpTZyTUxmYWJ1M05wfJLXozo_nG6cjsqpQJ66ha9XajtsqlXsezsFMd99wvnUHo2NS_RiCe6qQ0ggkPA01r8cNo8OvTE2d_hhJNRseN8ty1VeV9xrHD6QfunuqVjCFDRFJnW0kqdkaQSqHC5oEo5Tk2QVhyjd0LZVLrg",
  payroll: "https://lh3.googleusercontent.com/aida-public/AB6AXuDGqmQT-YJVBiQy6LEUc8trIVeOVRRLhBvFdAE2Yr8VAvR-dErhe9mRrdB3dz1l0dgCOmYrNGJ3c8FpiULk6ncICjpXCCnMSBSwCiYHTE6hpAYJ3z1aA9YmIfRiVO3JPfSoV7EIgxDe912Fnn3ADWEWhF8Hh_-YOkjlVC7aezsidgrQB3VhlV8l-VR9-TZ1G4aG7n9PsY9mU092_7aNtAapp-AES_RMnMsfinWdX_nvdxU3PzBoW5_w-A"
};
